// src/main/java/com/example/travelproject/TravelProjectApplication.java
package com.example.travelproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(TravelProjectApplication.class, args);
    }
}
